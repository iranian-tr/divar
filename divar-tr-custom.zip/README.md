# Divar Türkiye - دیوار ترکیه

Bu proje iranian.tr topluluğu tarafından desteklenmektedir.  
Gruplar:  
- Karyabi TR: https://t.me/karyabiTR  
- Istanbul Wall (İkinci El): https://t.me/istanbulwall  
